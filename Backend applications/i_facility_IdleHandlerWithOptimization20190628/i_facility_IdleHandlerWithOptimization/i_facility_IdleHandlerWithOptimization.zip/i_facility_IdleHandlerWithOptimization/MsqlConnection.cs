﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace i_facility_IdleHandlerWithOptimization
{
    class MsqlConnection:IDisposable
    {
        //static String ServerName = @"TCP:TSAL-DAS\TSALSQLEXPDAS";
        //static String username = "sa";
        //static String password = "srks4$tsal";
        //static String DB = "i_facility_tsal"; 

        static String ServerName = @"TCP:DESKTOP-M96NU10\SQLEXPRESS,7015";
        static String username = "sa";
        static String password = "srks4$";
        static String DB = "i_facility_tsal";



        public SqlConnection sqlConnection = new SqlConnection(@"Data Source = " + ServerName + ";User ID = " + username + ";Password = " + password + ";Initial Catalog = " + DB + ";Persist Security Info=True");

        public void open()
        {
            if (sqlConnection.State != System.Data.ConnectionState.Open)
                sqlConnection.Open();
        }

        public void close()
        {
            sqlConnection.Close();
        }

        public void Dispose()
        {
            sqlConnection.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}

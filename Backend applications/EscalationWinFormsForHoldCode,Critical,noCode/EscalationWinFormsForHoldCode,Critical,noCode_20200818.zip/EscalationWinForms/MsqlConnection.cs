﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data;
using System.Collections.ObjectModel;
using System.Collections;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Configuration;

namespace TataMySqlConnection
{
    class MsqlConnection:IDisposable
    {
        //static String ServerName = @"SRKSDEV001-PC\SQLSERVER17";
        //static String username = "sa";
        //static String password = "srks4$";
        //static String port = "3306";
        //static String DB = "i_facility_tsal";

        static String ServerName = ConfigurationManager.AppSettings["ServerName"];
        static String username = ConfigurationManager.AppSettings["username"];
        static String password = ConfigurationManager.AppSettings["password"];
        static String port = "3306";
        static String DB = ConfigurationManager.AppSettings["DB"]; 


        public SqlConnection msqlConnection = new SqlConnection(@"Data Source = " + ServerName + ";User ID = " + username + ";Password = " + password + ";Initial Catalog = " + DB + ";Persist Security Info=True");

        public void open()
        {
            if (msqlConnection.State != System.Data.ConnectionState.Open)
                msqlConnection.Open();
        }

        public void close()
        {
            if (msqlConnection.State != System.Data.ConnectionState.Closed)
                msqlConnection.Close();
        }

        public void Dispose()
        {
            msqlConnection.Dispose();
            GC.SuppressFinalize(this);
        }

        void IDisposable.Dispose()
        {
        }
    }
}
